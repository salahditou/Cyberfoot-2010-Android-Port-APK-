# Cómo publicar en GitHub Pages
1. Creá una cuenta en github.com y un repositorio **público** (por ejemplo `cyberfoot`).
2. En el repositorio: Add file -> Upload files, y arrastrá TODO el contenido de esta carpeta (no la carpeta en sí). Commit.
3. Settings -> Pages -> Source: "Deploy from a branch" -> Branch `main` / `(root)` -> Save.
4. Esperá 1-2 minutos y abrí `https://TUUSUARIO.github.io/cyberfoot/` en el celular.
5. En pwabuilder.com pegá esa dirección y elegí Android para generar el APK.
